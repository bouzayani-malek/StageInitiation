<?php

//conection a ma base de donner 

$conn= mysqli_connect('localhost','root','','magasin');


//selection du tableau produits
 $requete="SELECT id_prod,nom,prix,image,caractere,quantite FROM `produits` WHERE id_prod=$_GET[id_prod]";
 $res=mysqli_query($conn,$requete);
 //selection du tableau produits
 $rquete="SELECT id_prod,nom,prix,image,caractere,quantite FROM `produits` WHERE id_prod=$_GET[id_prod]";
 $re=mysqli_query($conn,$rquete);
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>ChezMalek - detailles</title>
	<link rel="icon" href="img/Fevicon.png" type="image/png">
  <link rel="stylesheet" href="vendors/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="vendors/fontawesome/css/all.min.css">
	<link rel="stylesheet" href="vendors/themify-icons/themify-icons.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
  <link rel="stylesheet" href="vendors/nice-select/nice-select.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.theme.default.min.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">

  <link rel="stylesheet" href="css/style.css">
</head>
<body>


  <!--================ Start Header Menu Area =================-->
<header class="header_area">
    <div class="main_menu">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
          <a class="navbar-brand logo_h"><img src="img/chezmalek.png" alt=""></a>
        </div>
      </nav>
    </div>
  </header>
  <!--================ End Header Menu Area =================-->


	
	
	
	
	<!-- ================ start banner area ================= -->	
	<section class="blog-banner-area" id="blog">
		<div class="container h-100">
			<div class="blog-banner">
				<div class="text-center">
					<h1>Détailles Produits</h1>
					<nav aria-label="breadcrumb" class="banner-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.php"><i style="color:blue">Accueil</i></a></li>
              <li class="breadcrumb-item active" aria-current="page">Produits</li>
            </ol>
          </nav>
				</div>
			</div>
    </div>
	</section>
	<!-- ================ end banner area ================= -->






 <!--================Single Product Area =================-->
	<div class="product_image_area">
		<div class="container">
			<div class="row s_product_inner">
			<?php
			            while ($lige=mysqli_fetch_array($re)){?>
			
				<div class="col-lg-6">
					<div class="owl-carousel owl-theme s_Product_carousel">
						<div class="single-prd-item">
							<img class="img-fluid" src="<?php echo $lige['image'] ?>" />
						</div>
					
					</div>
				</div>
				<?php }?>
				
				<div class="col-lg-5 offset-lg-1">
					<div class="s_product_text">
					<?php
			            while ($lig=mysqli_fetch_array($res)){?>
			          
					
					
						<h3><?php echo $lig['nom'] ?></h3>
						<h2><?php echo $lig['prix'] ?></h2>
					
						<p><?php echo $lig['caractere'] ?></p>
						
						<?php if($lig['quantite']!=0){ ?>
						<div class="product_count">						
							<a class="button primary-btn" href="commande.php?com=<?php echo $lig['id_prod'] ?>">Achetez</a>               
						</div>
						<?php }else{ ?>
				        <div class="product_count">	
				            <p class="card-product__price" style="color:red">Indisponible</p>
				        </div>
				    <?php }?>
						
						<?php }?>
						
					</div>
				</div>
				
			</div>
		</div>
	</div>
	<!--================End Single Product Area =================-->

  <!--================ Start footer Area  =================-->	
	<footer>
		<div class="footer-area footer-only">
			<div class="container">
	<div class="cart_inner">
		  
		  
              <div class="table-responsive">
							<table class="table">
                      <thead>
                          <tr style="color:yellow">
                              <th style="color:yellow ;" scope="col">
							  <p class="sm-head"><span class="fa fa-location-arrow"style="color:red"></span>  Siège social</p>
							 </th>
                              <th style="color:yellow;text-align: center" scope="col">
							    <p class="sm-head"><span class="fa fa-phone"style="color:red"></span>  Numéro de téléphone</p>
							 </th>
                              <th style="color:yellow;text-align:right" scope="col">
							  <p class="sm-head"><span class="fa fa-envelope" style="color:red"></span>  E-mail</p>
							  </th>
						</tr>
					 </thead>
					 <tbody>
					 <tr>
					 <td>
					 <p>123,Rue principale,Ta ville</p>
					 </td>
					 <td style="text-align: center">
					 <p>+216 20969466</p>
					 </td>
					 <td style="text-align: right">
					 <p>www.chezmalek.com</p>
					 </td>
					 </tr>
					 
					 </tbody>
							</table>
						
					</div>
				</div>
			</div>
		</div>

		
	</footer>
	<!--================ End footer Area  =================-->


  <script src="vendors/jquery/jquery-3.2.1.min.js"></script>
  <script src="vendors/bootstrap/bootstrap.bundle.min.js"></script>
  <script src="vendors/skrollr.min.js"></script>
  <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
  <script src="vendors/nice-select/jquery.nice-select.min.js"></script>
  <script src="vendors/jquery.form.js"></script>
  <script src="vendors/jquery.validate.min.js"></script>
  <script src="vendors/contact.js"></script>
  <script src="vendors/jquery.ajaxchimp.min.js"></script>
  <script src="vendors/mail-script.js"></script>
  <script src="js/main.js"></script>
</body>
</html>