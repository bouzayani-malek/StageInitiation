<?php

//conection a ma base de donner 

$conn= mysqli_connect('localhost','root','','magasin');


//selection du tableau commande
 $ree="SELECT id_com,nom,prenom,telephone,adresse,quantite,prix_totale,id_prod,etat FROM `commande` WHERE etat='F' ";
 $rss=mysqli_query($conn,$ree);

  //selection du categorie
 $reque="SELECT id_cat,libeler_produit FROM `categorie` ";
 $ress=mysqli_query($conn,$reque);
 
 session_start();
 $_SESSION["id"];
function isLoginSessionExpired() {
	$login_session_duration = 1800; 
	$current_time = time(); 
	if(isset($_SESSION['loggedin_time']) and isset($_SESSION["user_id"])){  
		if(((time() - $_SESSION['loggedin_time']) > $login_session_duration)){ 
			return true; 
		} 
	}
	return false;
}
if(isset($_SESSION["user_id"])) {
	if(isLoginSessionExpired()) {
		header("Location:logout.php?session_expired=1");
	}
}
 
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>ChezMalek-Commande</title>
	<link rel="icon" href="img/Fevicon.png" type="image/png">
  <link rel="stylesheet" href="vendors/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="vendors/fontawesome/css/all.min.css">
	<link rel="stylesheet" href="vendors/themify-icons/themify-icons.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.theme.default.min.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
  <link rel="stylesheet" href="vendors/nice-select/nice-select.css">
  <link rel="stylesheet" href="vendors/nouislider/nouislider.min.css">
 <link rel="stylesheet" href="css/sty.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<!--================ Start Header Menu Area =================-->
	<header class="header_area">
    <div class="main_menu">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
          <a class="navbar-brand logo_h"><img src="img/chezmalek.png" alt=""></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
            <ul class="nav navbar-nav menu_nav ml-auto mr-auto">
              
             
			  
			  
              <li class="nav-item submenu dropdown">
                <a class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                  aria-expanded="false">produit</a>
                <ul class="dropdown-menu">
                  <li class="nav-item"><a class="nav-link" href="insprod.php">Ajouter produit</a></li>
                  <li class="nav-item"><a class="nav-link" href="listeprod.php">liste produit</a></li>
                </ul>
			 </li>
			 
			 
				<li class="nav-item submenu dropdown">
                <a  class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                  aria-expanded="false">categorie</a>
                <ul class="dropdown-menu">
                  <li class="nav-item"><a class="nav-link" href="insertioncategorie.php">Ajouter categorie</a></li>
                 <li class="nav-item"><a class="nav-link" href="listecat.php">liste categorie</a></li>
                </ul>
              </li>
			  <li class="nav-item submenu dropdown">
                <a  class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                  aria-expanded="false">commande</a>
			  <ul class="dropdown-menu">
			  <li class="nav-item"><a class="nav-link" href="commandedeproduit.php">liste Commande </a></li>
			   <li class="nav-item"><a class="nav-link" href="commandeaccepter.php">Accepter </a></li>
             </ul>
			 </li>
            </ul>
             <ul>
			  <li class="nav-item submenu dropdown">
			  
                <a  class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                  aria-expanded="false">parametre</a>
			  <ul class="dropdown-menu">
              <li class="nav-item"><a class="nav-link" href="logout.php">Déconnecte</a></li>			
            <li class="nav-item"><a class="nav-link" href="malek.php?id=<?php echo $_SESSION["id"]; ?>">Modifier Admin</a></li>
            </ul>
			</li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  </header>
	<!--================ End Header Menu Area =================-->

  
  
  <!--================Checkout Area =================-->
 <section class="section-margin--small mb-5">
    <div class="container">
	
	<div class="cart_inner">
		  
		  
              <div class="table-responsive">
                  <table class="table">
                      <thead>
                          <tr>
                              <th scope="col">Nom:</th>
                              <th scope="col">Prenom:</th>
                              <th scope="col">produit:</th>
							  <th scope="col">quantite:</th>
							  <th scope="col">adresse:</th>
                              <th scope="col">telephone:</th>
                              <th scope="col">prix:</th>
							  <th scope="col">etat:</th>
							  <th scope="col">modifier:</th>
                          </tr>
                      </thead>
					   <tbody> 
					    <?php while ($lig=mysqli_fetch_array($rss)){?>                     
					  <tr>                       
                              
                                  
                                       <?php  $bb=$lig['id_com'];?> 
                               
                              
							  
                              <td>
                                 <?php echo $lig['nom']; ?>
                              </td>
							  <td>
                                  <?php echo $lig['prenom']; ?>
                              </td>
							  <td>
							  <?php 
							  $b=$lig['id_prod'];
							  //selection du tableau produits
                                 $re="SELECT nom,quantite FROM `produits` WHERE id_prod=$b";
                                 $rs=mysqli_query($conn,$re);
							  while ($li=mysqli_fetch_array($rs)){
                                  echo $li['nom'];
								  
                                   $quantite_initial=$li['quantite'];	
								 
								  }?>
                              </td>
							  <td>
                                  <?php $qty= $lig['quantite']; echo $qty ;
								  
								  $quantite_final=$quantite_initial-$qty;
								 
								  
								  
								  
								  ?>
                              </td>
							  <td>
                                  <?php echo $lig['adresse']; ?>
                              </td>
							  <td>
                                  <?php echo $lig['telephone']; ?>
                              </td>
                              
                              <td>
                                  <?php echo $lig['prix_totale']; ?>DT
                              </td>
							  <td>  
                                   <form action="" method="post">							  
								<input type="image" src="jouet/malek.jpg" name="etat" class="mahamed" width="40px" height="40px" />	
								<input type="hidden" name="hiddenetat" value="<?php echo $bb; ?>" />
								<input type="hidden" name="hid" value="<?php echo   $quantite_final; ?>" />
								<input type="hidden" name="hidd" value="<?php echo $b; ?>" />
								</form>
                              </td>
                         <td>  						  
							  <a href="modifi.php?mod=<?php echo$bb; ?>"><img src="jouet/mod.png" name="etat" class="malek" width="50px" height="50px" /></a>										
                         </td>
						  
						  
                         
                     </tr>
					  <?php }?>
					    </tbody>
                  </table>
              </div>
			  
			  
			  
			  
			  
          </div>
	 </div>
	</section>
	    
					  <?php 
				
								if(isset($_POST['etat_x'])){
									 $etat=$_POST['hiddenetat'];
									 $h=$_POST['hidd'];
									 $qua=$_POST['hid'];
									 $SQL="UPDATE `commande` SET `etat`='T' WHERE id_com=$etat";
			                         mysqli_query($conn,$SQL);
									 $SQ="UPDATE `produits` SET `quantite`=$qua WHERE id_prod=$h";
									 mysqli_query($conn,$SQ);
								
									
								}
								?>
	<!-- ================ end banner area ================= -->
  
  <script src="vendors/jquery/jquery-3.2.1.min.js"></script>
  <script src="vendors/bootstrap/bootstrap.bundle.min.js"></script>
  <script src="vendors/skrollr.min.js"></script>
  <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
  <script src="vendors/nice-select/jquery.nice-select.min.js"></script>
  <script src="vendors/jquery.ajaxchimp.min.js"></script>
  <script src="vendors/mail-script.js"></script>
  <script src="js/main.js"></script>
</body>
</html>