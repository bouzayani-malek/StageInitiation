<?php session_start();
function isLoginSessionExpired() {
	$login_session_duration =1800; 
	$current_time = time(); 
	if(isset($_SESSION['loggedin_time']) and isset($_SESSION["user_id"])){  
		if(((time() - $_SESSION['loggedin_time']) > $login_session_duration)){ 
			return true; 
		} 
	}
	return false;
}

//connecte avec base de donner
$conn= mysqli_connect('localhost','root','','magasin');


$message="";
if(count($_POST)>0) {
	//selection du tableau produits
 $requ="SELECT id_ad,user,passe FROM `admin` ";
 $res=mysqli_query($conn,$requ);
	   while($li=mysqli_fetch_array($res)){
		   if($li['id_ad']==1){
			   //MALEK
				$admin1=$li['user'];
				$mdp1=$li['passe'];	
 				
		   }
		   if($li['id_ad']==2){
			   //MALEK
				$admin2=$li['user'];
				$mdp2=$li['passe'];	   
		   }
	   }
	if( $_POST["user_name"] == $admin1 and $_POST["password"] == $mdp1) {
		$_SESSION["user_id"] = 1001;
		$_SESSION["id"] = 1;
		$_SESSION["user_name"] = $_POST["user_name"];
		$_SESSION['loggedin_time'] = time();
    } elseif ( $_POST["user_name"] == $admin2 and $_POST["password"] == $mdp2) {
        $_SESSION["user_id"] = 1001;
		$_SESSION["id"] =2;
		$_SESSION["user_name"] = $_POST["user_name"];
		$_SESSION['loggedin_time'] = time();
		
	} else {
		$message = "Invalid Username or Password!";
	}
}
if(isset($_SESSION["user_id"])) {
	if(!isLoginSessionExpired()) {
		header("Location:user_dashboard.php");
	} else {
		header("Location:logout.php?session_expired=1");
	}
}
if(isset($_GET["session_expired"])) {
	$message="Login session is expired. Login Again ";
	
}





?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>ChezMalek-Admin</title>
	<link rel="icon" href="img/Fevicon.png" type="image/png">
  <link rel="stylesheet" href="vendors/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="vendors/fontawesome/css/all.min.css">
	<link rel="stylesheet" href="vendors/themify-icons/themify-icons.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.theme.default.min.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
  <link rel="stylesheet" href="vendors/nice-select/nice-select.css">
  <link rel="stylesheet" href="vendors/nouislider/nouislider.min.css">

  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<!--================ Start Header Menu Area =================-->
	<header class="header_area">
    <div class="main_menu">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
          <a class="navbar-brand logo_h"><img src="img/chezmalek.png" alt=""></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
            <ul class="nav navbar-nav menu_nav ml-auto mr-auto">
              
             
			  
			  
              <li class="nav-item submenu dropdown">
                <a class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                  aria-expanded="false"></a>
                <ul class="dropdown-menu">
                  <li class="nav-item"><a class="nav-link" ></a></li>
                  <li class="nav-item"><a class="nav-link" ></a></li>
                </ul>
			 </li>
			 
			 
				<li class="nav-item submenu dropdown">
                <a  class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                  aria-expanded="false"></a>
                <ul class="dropdown-menu">
                  <li class="nav-item"><a class="nav-link"></a></li>
                 <li class="nav-item"><a class="nav-link" ></a></li>
                </ul>
              </li>
			  <li class="nav-item submenu dropdown">
                <a  class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                  aria-expanded="false"></a>
			  <ul class="dropdown-menu">
			  <li class="nav-item"><a class="nav-link" ></a></li>
             </ul></li>
            </ul>

            
          </div>
        </div>
      </nav>
    </div>
  </header>
	

<!-- ================ end banner area ================= -->
	
	<section class="login_box_area section-margin ">
		<div class="container">
			<div class="row">
			<div class="col-lg-6">
					<div >
						<div class="hover">
							
							<p><img src="img/mmm.png" alt=""></p>
							
						</div>
					</div>
				</div>

			
				<div class="col-lg-6">
					<div class="login_form_inner register_form_inner ">
						
						
						
						<form class="row login_form" name="frmUser" method="post" action="" id="register_form" >
							<?php if($message!="") {
	                                 ?>
									 <div class="col-md-12 form-group">
                                       <p><?php echo $message; ?></p>
								     </div><br/><br/><br/>
                                      <?php } ?>
							<div class="col-md-12 form-group">
							 <label for="name"><h6>Espace Admin :</h6></label>
							 
								<input type="text" class="form-control" id="name" name="user_name" placeholder="Inserer ton pseudo" >
							 </div>

                               <div class="col-md-12 form-group">							   
								<input  class="form-control"  name="password"  type="password" placeholder="********">
						    	</div>
	
							<div class="col-md-12 form-group">
								<input type="submit" value="connecte toi!" name="submit" class="button button-register w-100"/>
							</div>
						</form>
						
						
					</div>
				</div>
				
				
			</div>
		</div>
	</section>
	
	
	<!-- ================ end banner area ================= -->
	<script src="vendors/jquery/jquery-3.2.1.min.js"></script>
  <script src="vendors/bootstrap/bootstrap.bundle.min.js"></script>
  <script src="vendors/skrollr.min.js"></script>
  <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
  <script src="vendors/nice-select/jquery.nice-select.min.js"></script>
  <script src="vendors/jquery.ajaxchimp.min.js"></script>
  <script src="vendors/mail-script.js"></script>
  <script src="js/main.js"></script>
</body>
</html>