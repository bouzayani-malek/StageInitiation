<?php

//conection a ma base de donner 

$conn= mysqli_connect('localhost','root','','magasin');
 
 //selection du base de donner 
 $requett="SELECT id_cat,libeler_produit,image_cat FROM `categorie` ";
 $k=mysqli_query($conn,$requett);
 
 session_start();
 $_SESSION["id"];
function isLoginSessionExpired() {
	$login_session_duration = 1800; 
	$current_time = time(); 
	if(isset($_SESSION['loggedin_time']) and isset($_SESSION["user_id"])){  
		if(((time() - $_SESSION['loggedin_time']) > $login_session_duration)){ 
			return true; 
		} 
	}
	return false;
}
if(isset($_SESSION["user_id"])) {
	if(isLoginSessionExpired()) {
		header("Location:logout.php?session_expired=1");
	}
}
 
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>ChezMalek-Liste Categorie</title>
	<link rel="icon" href="img/Fevicon.png" type="image/png">
  <link rel="stylesheet" href="vendors/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="vendors/fontawesome/css/all.min.css">
	<link rel="stylesheet" href="vendors/themify-icons/themify-icons.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.theme.default.min.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
  <link rel="stylesheet" href="vendors/nice-select/nice-select.css">
  <link rel="stylesheet" href="vendors/nouislider/nouislider.min.css">
 <link rel="stylesheet" href="css/sty.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<!--================ Start Header Menu Area =================-->
	<header class="header_area">
    <div class="main_menu">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
          <a class="navbar-brand logo_h"><img src="img/chezmalek.png" alt=""></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
            <ul class="nav navbar-nav menu_nav ml-auto mr-auto">
              
             
			  
			  
              <li class="nav-item submenu dropdown">
                <a class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                  aria-expanded="false">produit</a>
                <ul class="dropdown-menu">
                  <li class="nav-item"><a class="nav-link" href="insprod.php">Ajouter produit</a></li>
                  <li class="nav-item"><a class="nav-link" href="listeprod.php">liste produit</a></li>
                </ul>
			 </li>
			 
			 
				<li class="nav-item submenu dropdown">
                <a  class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                  aria-expanded="false">categorie</a>
                <ul class="dropdown-menu">
                  <li class="nav-item"><a class="nav-link" href="insertioncategorie.php">Ajouter categorie</a></li>
                 <li class="nav-item"><a class="nav-link" href="listecat.php">liste categorie</a></li>
                </ul>
              </li>
			  <li class="nav-item submenu dropdown">
                <a  class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                  aria-expanded="false">commande</a>
			  <ul class="dropdown-menu">
			  <li class="nav-item"><a class="nav-link" href="commandedeproduit.php">liste Commande </a></li>
			   <li class="nav-item"><a class="nav-link" href="commandeaccepter.php">Accepter </a></li>
             </ul>
			 </li>
            </ul>
             <ul>
			  <li class="nav-item submenu dropdown">
			  
                <a  class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                  aria-expanded="false">parametre</a>
			  <ul class="dropdown-menu">
              <li class="nav-item"><a class="nav-link" href="logout.php">Déconnecte</a></li>			
              <li class="nav-item"><a class="nav-link" href="malek.php?id=<?php echo $_SESSION["id"]; ?>">Modifier Admin</a></li>
            </ul>
			</li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  </header>
	<!--================ End Header Menu Area =================-->
	
	
	
	<!--================Cart Area =================-->
  <section class="cart_area">
      <div class="container">
          <div class="cart_inner">
		  
		  
              <div class="table-responsive">
                  <table class="table">
                      <thead>
                          <tr>
                              <th scope="col">Image categorie:</th>
                             <th scope="col">Nom categorie:</th>
							  <th scope="col">Supprimer:</th>
                             <th scope="col">Modifier:</th>
                          </tr>
                      </thead>
					  <?php while ($hh=mysqli_fetch_array($k)){?>
                      <tbody>
					  
                          <tr>
                              <td>
                                
                                          <img src="<?php echo $hh['image_cat']; ?>" width="70px"/>
                              
                              </td>
                              <td>
                                  <h5><?php echo $hh['libeler_produit']; ?></h5>
                              </td>
                               <td>  
                                   <form action="" method="post">							  
							      	<input type="image" src="jouet/sup.jpg" name="etat" class="malek" width="50px" height="50px" />	
							    	<input type="hidden" name="hiddenetat" value="<?php $rr=$hh['id_cat'];echo $rr; ?>" />
								   </form>					  
                              </td>
                              <td>  
                                  							  
							      	<a href="mod.php?mod=<?php echo $rr; ?>"><img src="jouet/mod.png" name="etat" class="malek" width="70px" height="70px" /></a>	
							    	
								  			  
                              </td>
							  
                      </tbody>
					  <?php }?>
                  </table>
              </div>
			  
			  
			  
			  
			  
          </div>
      </div>
  </section>
  
  <?php 
				
								if(isset($_POST['etat_x'])){
									 $delete=$_POST['hiddenetat'];
									$SQL="DELETE FROM `categorie` WHERE id_cat=$delete";
			                         mysqli_query($conn,$SQL);
									 
								}
								?>
  <!--================End Cart Area =================-->
	
	<!-- ================ end banner area ================= -->
	<script src="vendors/jquery/jquery-3.2.1.min.js"></script>
  <script src="vendors/bootstrap/bootstrap.bundle.min.js"></script>
  <script src="vendors/skrollr.min.js"></script>
  <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
  <script src="vendors/nice-select/jquery.nice-select.min.js"></script>
  <script src="vendors/jquery.ajaxchimp.min.js"></script>
  <script src="vendors/mail-script.js"></script>
  <script src="js/main.js"></script>
</body>
</html>
