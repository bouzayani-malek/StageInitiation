<?php
//conection a ma base de donner 
$conn= mysqli_connect('localhost','root','','magasin');
//selection du base de donner 

  $reque="SELECT id_cat,libeler_produit,image_cat FROM `categorie` ";
  $ress=mysqli_query($conn,$reque);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>ChezMalek - Accueil</title>
	<link rel="icon" href="img/Fevicon.png" type="image/png">
  <link rel="stylesheet" href="vendors/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="vendors/fontawesome/css/all.min.css">
	<link rel="stylesheet" href="vendors/themify-icons/themify-icons.css">
  <link rel="stylesheet" href="vendors/nice-select/nice-select.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.theme.default.min.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
<link rel="stylesheet" href="css/sty.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <!--================ Start Header Menu Area =================-->
<header class="header_area">
    <div class="main_menu">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
          <a class="navbar-brand logo_h"><img src="img/chezmalek.png" alt=""></a>
        </div>
      </nav>
    </div>
  </header>
  <!--================ End Header Menu Area =================-->
  
  <!-- ================ start banner area ================= -->	
	<section class="blog-banner-area" id="blog">
		<div class="container h-100">
			<div class="blog-banner">
				<div class="text-center">
					<h1>Accueil</h1>
						<nav aria-label="breadcrumb" class="banner-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item active" aria-current="page">Categorie</li>
            </ol>
				</div>
			</div>
    </div>
	</section>
	<!-- ================ end banner area ================= -->


  	<!-- ================ category section start ================= -->		  
  <section class="section-margin--small mb-5">
    <div class="container">
          <!-- Start Best Seller -->		  
          <section class="lattest-product-area pb-40 category-list">
            <div class="row">		
			 <?php 
		  while ($ligne=mysqli_fetch_array($ress)){
		  ?> 	
                 <div class="col-md-6 col-lg-4">			  
                <div class="card text-center card-product">
				<a href="liste produit.php?id=<?php echo $ligne['id_cat'] ?>&categorie=<?php echo $ligne['libeler_produit'] ?>">
                  <div class="card-product__img">				  
                    <img class="card-img mahamed" src="<?php echo $ligne['image_cat'] ?>" >
					<ul class="card-product__imgOverlay">
                      <li><i >Produits</i></li>
                      
                    </ul>
                  </div>
				</a>				
                  <div class="card-body">                 
                    <h4 class="card-product__title"><?php echo $ligne['libeler_produit'] ?></h4>               
                  </div>			  
                </div>				
              </div>			  
			  <?php
		  }?>           
            </div>
          </section>
          <!-- End Best Seller -->
    </div>
  </section>
	<!-- ================ category section end ================= -->	
	
 <!--================ Start footer Area  =================-->	
	<footer>
		<div class="footer-area footer-only">
			<div class="container">
	<div class="cart_inner">
		  
		  
              <div class="table-responsive">
							<table class="table">
                      <thead>
                          <tr style="color:yellow">
                              <th style="color:yellow ;" scope="col">
							  <p class="sm-head"><span class="fa fa-location-arrow"style="color:red"></span>  Siège social</p>
							 </th>
                              <th style="color:yellow;text-align: center" scope="col">
							    <p class="sm-head"><span class="fa fa-phone"style="color:red"></span>  Numéro de téléphone</p>
							 </th>
                              <th style="color:yellow;text-align:right" scope="col">
							  <p class="sm-head"><span class="fa fa-envelope" style="color:red"></span>  E-mail</p>
							  </th>
						</tr>
					 </thead>
					 <tbody>
					 <tr>
					 <td>
					 <p>123,Rue principale,Ta ville</p>
					 </td>
					 <td style="text-align: center">
					 <p>+216 20969466</p>
					 </td>
					 <td style="text-align: right">
					 <p>www.chezmalek.com</p>
					 </td>
					 </tr>
					 
					 </tbody>
							</table>
						
					</div>
				</div>
			</div>
		</div>

		
	</footer>
	<!--================ End footer Area  =================-->



  <script src="vendors/jquery/jquery-3.2.1.min.js"></script>
  <script src="vendors/bootstrap/bootstrap.bundle.min.js"></script>
  <script src="vendors/skrollr.min.js"></script>
  <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
  <script src="vendors/nice-select/jquery.nice-select.min.js"></script>
  <script src="vendors/jquery.form.js"></script>
  <script src="vendors/jquery.validate.min.js"></script>
  <script src="vendors/contact.js"></script>
  <script src="vendors/jquery.ajaxchimp.min.js"></script>
  <script src="vendors/mail-script.js"></script>
  <script src="js/main.js"></script>
</body>
</html>