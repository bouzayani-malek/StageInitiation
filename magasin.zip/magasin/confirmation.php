<?php
//conection a ma base de donner 

$conn= mysqli_connect('localhost','root','','magasin');
//reception des donnees du formulaires 
 $NOM=$_POST['name'];

 $PRE=$_POST['prenom'];

 $MAIL=$_POST['email'];

 $TEL =$_POST['telphone'];

 $ADD=$_POST['adresse'];

 $COM=$_POST['commentaire'];
 
 $QAT=$_POST['qty'];
 

// fonction calcule le prix totale 
                              function CalcuTotal($QAT, $PRIX)
                                { $PRIXTOTALE = $QAT * $PRIX ; // calcul du prix totale
                                   return $PRIXTOTALE ; // indique la valeur à renvoyer
                                 }
//selection du tableau produits
 $requet="SELECT id_prod,nom,prix,image,caractere,quantite FROM `produits` WHERE id_prod=$_GET[conf]";
 $resss=mysqli_query($conn,$requet);
 while($liii=mysqli_fetch_array($resss)){

 $NOM_PROD=$liii['nom'];
 $PRIX=$liii['prix'];
 }
 $PRIXTOTALE = CalcuTotal($QAT, $PRIX);
 $TOT=$PRIXTOTALE +7.000;
 //insertion des donners
$req="INSERT INTO `commande`(`nom`,`prenom`,`telephone`,`adresse`,`e_mail`,`quantite`,`prix_totale`,`commentaire`,`etat`,`id_prod`) VALUES ('$NOM','$PRE','$TEL','$ADD','$MAIL',$QAT,'$PRIXTOTALE','$COM','F',$_GET[conf])";
$res=mysqli_query($conn,$req);

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>ChezMalek - Confirmation</title>
	<link rel="icon" href="img/Fevicon.png" type="image/png">
  <link rel="stylesheet" href="vendors/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="vendors/fontawesome/css/all.min.css">
	<link rel="stylesheet" href="vendors/themify-icons/themify-icons.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.theme.default.min.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">

  <link rel="stylesheet" href="css/style.css">
</head>







<body>
    <!--================ Start Header Menu Area =================-->
<header class="header_area">
    <div class="main_menu">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
          <a class="navbar-brand logo_h"><img src="img/chezmalek.png" alt=""></a>
        </div>
      </nav>
    </div>
  </header>
  <!--================ End Header Menu Area =================-->
  <!-- ================ start banner area ================= -->	
	<section class="blog-banner-area" id="category">
		<div class="container h-100">
			<div class="blog-banner">
				<div class="text-center">
					<h2><?php
	                    if($QAT != 0){ echo "Félicitations!!,votre commande a enregistré.";}
	                      else
	                         {
	                           echo "Votre commande n'a pas enregistré!!!";} ?></h2>
					<nav aria-label="breadcrumb" class="banner-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.php"><i style="color:blue">Accueil</i></a></li>
              <li class="breadcrumb-item active" aria-current="page">Confirmation</li>
            </ol>
          </nav>
				</div>
			</div>
    </div>
	</section>
	<!-- ================ end banner area ================= -->
  
  
  
  <section class="order_details section-margin--small">
    <div class="container">
	
      <div class="order_details_table">
            <h2>Commande de :</h2> 
			<div class="table-responsive">
            <table class="table">
			
              <tr >
                <th>Nom :</th>  
                 <th><?php echo  $NOM; ?></th>
              </tr>
              <tr >
                 <th>Prenom :</th>  
                 <th><?php echo $PRE; ?></th>
              </tr>
              <tr>
                <th>Telephone :</th>   
                 <th><?php echo $TEL; ?></th>
              </tr>
              <tr>
                <th>Addresse :</th>  
                <th><?php echo $ADD; ?></th>
              </tr>
			  
			  
            </table>
          </div>
      </div>
	  
	  
      <div class="order_details_table">
 <h2>Facture :</h2> 
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">Name Produit :</th>
                <th scope="col">Quantité :</th>
                <th scope="col">Total :</th>
				<th scope="col">Forfait :</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <p><?php echo $NOM_PROD; ?></p>
                </td>
                <td>
                  <p><?php echo "x ",$_POST['qty']; ?></p>
                </td>
                <td>
                  <p><?php 
                           echo $PRIXTOTALE,"DT";				                 
				     ?>
                </td>
				 <td>
                  <p>7.000DT</p>
                </td>
				
              </tr>
             
            
              <tr>
                <td>
                  <h4>Total prix :</h4>
                </td>
              
                <td>
                  <h5><?php 				  				  
				  echo $TOT,"DT";
				  ?> </h5>
                </td>
				 <td>
                  <h5></h5>
                </td>
				 <td>
                  <h5></h5>
                </td>
				
              </tr>
            </tbody>
          </table>
        </div>
      </div>
	  
	  
	  
	  
	  
	  
	  
    </div>
  </section>
  <!--================End Order Details Area =================-->

  
  <!--================ Start footer Area  =================-->	
	<footer>
		<div class="footer-area footer-only">
			<div class="container">
	<div class="cart_inner">
		  
		  
              <div class="table-responsive">
							<table class="table">
                      <thead>
                          <tr style="color:yellow">
                              <th style="color:yellow ;" scope="col">
							  <p class="sm-head"><span class="fa fa-location-arrow"style="color:red"></span>  Siège social</p>
							 </th>
                              <th style="color:yellow;text-align: center" scope="col">
							    <p class="sm-head"><span class="fa fa-phone"style="color:red"></span>  Numéro de téléphone</p>
							 </th>
                              <th style="color:yellow;text-align:right" scope="col">
							  <p class="sm-head"><span class="fa fa-envelope" style="color:red"></span>  E-mail</p>
							  </th>
						</tr>
					 </thead>
					 <tbody>
					 <tr>
					 <td>
					 <p>123,Rue principale,Ta ville</p>
					 </td>
					 <td style="text-align: center">
					 <p>+216 20969466</p>
					 </td>
					 <td style="text-align: right">
					 <p>www.chezmalek.com</p>
					 </td>
					 </tr>
					 
					 </tbody>
							</table>
						
					</div>
				</div>
			</div>
		</div>

		
	</footer>
	<!--================ End footer Area  =================-->



  <script src="vendors/jquery/jquery-3.2.1.min.js"></script>
  <script src="vendors/bootstrap/bootstrap.bundle.min.js"></script>
  <script src="vendors/skrollr.min.js"></script>
  <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
  <script src="vendors/nice-select/jquery.nice-select.min.js"></script>
  <script src="vendors/jquery.form.js"></script>
  <script src="vendors/jquery.validate.min.js"></script>
  <script src="vendors/contact.js"></script>
  <script src="vendors/jquery.ajaxchimp.min.js"></script>
  <script src="vendors/mail-script.js"></script>
  <script src="js/main.js"></script>
</body>
</html>