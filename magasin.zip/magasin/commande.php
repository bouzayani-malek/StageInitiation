<?php

//conection a ma base de donner 

$conn= mysqli_connect('localhost','root','','magasin');

//selection du tableau produits
 $requete="SELECT id_prod,nom,prix,image,caractere,quantite FROM `produits` WHERE id_prod=$_GET[com]";
 $res=mysqli_query($conn,$requete);
 //selection du tableau produits
 $reque="SELECT id_prod,nom,prix,image,caractere,quantite FROM `produits` WHERE id_prod=$_GET[com]";
 $ress=mysqli_query($conn,$reque);
 while($lii=mysqli_fetch_array($ress)){
 $conf= $lii['id_prod'];}
	
?>



<!DOCTYPE>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>ChezMalek - Commande</title>
	<link rel="icon" href="img/Fevicon.png" type="image/png">
  <link rel="stylesheet" href="vendors/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="vendors/fontawesome/css/all.min.css">
	<link rel="stylesheet" href="vendors/themify-icons/themify-icons.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.theme.default.min.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">

  <link rel="stylesheet" href="css/style.css">
</head>


<body>


   <!--================ Start Header Menu Area =================-->
<header class="header_area">
    <div class="main_menu">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
          <a class="navbar-brand logo_h"><img src="img/chezmalek.png" alt=""></a>
        </div>
      </nav>
    </div>
  </header>
  <!--================ End Header Menu Area =================-->

  
  
  
  
<!-- ================ start banner area ================= -->	
	<section class="blog-banner-area" id="category">
		<div class="container h-100">
			<div class="blog-banner">
				<div class="text-center">
					<h1>Commande</h1>
					<nav aria-label="breadcrumb" class="banner-breadcrumb">
                         <ol class="breadcrumb">
                           <li class="breadcrumb-item"><a href="index.php"><i style="color:blue">Accueil</i></a></li>
                           <li class="breadcrumb-item active" aria-current="page">Achetez</li>
                         </ol>
                   </nav>
				</div>
			</div>
        </div>
	</section>
	<!-- ================ end banner area ================= -->












	<!-- ================ contact section start ================= -->
  <section class="section-margin--small">
    <div class="container">	
	<div class="col-md-8 col-lg-9">
          <form action="confirmation.php?conf=<?php echo $conf ; ?>"  method="post"  class="form-contact" id="contactForm1" novalidate="novalidate">
            <div class="table-responsive">
              <table class="table">		  
                <tr class="form-group">
                  <th><label for="name">Nom:</label></th><td><input class="form-control" name="name" id="name" type="text" placeholder="Enter your name"></td>
                </tr>			
			<tr class="form-group">
                  <th><label for="prenom">Prénom:</label></th><td><input class="form-control" name="prenom" id="prenom" type="text" placeholder="Enter your prénom">
                </td></tr>				
                <tr class="form-group">
                <th>  <label for="email">E-mail:</label></th><td><input class="form-control" name="email" id="email" type="email" placeholder="Enter email address"></td> 
				</tr>
			     <tr class="form-group">
				   <th><label for="tele">Telephone:</label></th><td><input class="form-control" name="telphone" id="tele" type="tel" placeholder="Telephone" /></td>
				  </tr>	               
				<tr class="form-group">
               <th>  <label for="ADRESSE">Addresse:</label></th> <td> <input class="form-control" name="adresse" id="ADRESSE" type="text" placeholder="Enter adresse"></td>
                </tr>
              <tr class="form-group">
                  <th><label for="message">Comentaire:</label></th>  <td><textarea class="form-control different-control w-100" name="commentaire" id="message" cols="30" rows="5" placeholder="Enter Message"></textarea></td>
                </tr>
				<tr class="form-group">
				<th><label >Quantité:</label></th>
				<td>
                      <div class="product_count form-control" >
                       <input type="text" name="qty" id="sst" maxlength="20" value="1" title="Quantity" class="input-text qty">
                           <button onclick="var result = document.getElementById('sst'); var sst = result.value; if( !isNaN( sst )) result.value++;return false;"
                              class="increase items-count" type="button"><i class="lnr lnr-chevron-up"></i></button>
                           <button onclick="var result = document.getElementById('sst'); var sst = result.value; if( !isNaN( sst ) &amp;&amp; sst > 0 ) result.value--;return false;"
                              class="reduced items-count" type="button"><i class="lnr lnr-chevron-down"></i></button>
                      </div>
                </td>
				</tr>
              </table>
			  </div>	
            <div class="form-group text-center text-md-right mt-3">			
              <input type="submit" class="button button--active button-contactForm" />            
		  </div> 
          </form>
        </div>      
      </div>
    </div>
  </section>
	
	
	
	
	
	
 <!--================ Start footer Area  =================-->	
	<footer>
		<div class="footer-area footer-only">
			<div class="container">
	<div class="cart_inner">
		  
		  
              <div class="table-responsive">
							<table class="table">
                      <thead>
                          <tr style="color:yellow">
                              <th style="color:yellow ;" scope="col">
							  <p class="sm-head"><span class="fa fa-location-arrow"style="color:red"></span>  Siège social</p>
							 </th>
                              <th style="color:yellow;text-align: center" scope="col">
							    <p class="sm-head"><span class="fa fa-phone"style="color:red"></span>  Numéro de téléphone</p>
							 </th>
                              <th style="color:yellow;text-align:right" scope="col">
							  <p class="sm-head"><span class="fa fa-envelope" style="color:red"></span>  E-mail</p>
							  </th>
						</tr>
					 </thead>
					 <tbody>
					 <tr>
					 <td>
					 <p>123,Rue principale,Ta ville</p>
					 </td>
					 <td style="text-align: center">
					 <p>+216 20969466</p>
					 </td>
					 <td style="text-align: right">
					 <p>www.chezmalek.com</p>
					 </td>
					 </tr>
					 
					 </tbody>
							</table>
						
					</div>
				</div>
			</div>
		</div>

		
	</footer>
	<!--================ End footer Area  =================-->



  <script src="vendors/jquery/jquery-3.2.1.min.js"></script>
  <script src="vendors/bootstrap/bootstrap.bundle.min.js"></script>
  <script src="vendors/skrollr.min.js"></script>
  <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
  <script src="vendors/nice-select/jquery.nice-select.min.js"></script>
  <script src="vendors/jquery.form.js"></script>
  <script src="vendors/jquery.validate.min.js"></script>
  <script src="vendors/contact.js"></script>
  <script src="vendors/jquery.ajaxchimp.min.js"></script>
  <script src="vendors/mail-script.js"></script>
  <script src="js/main.js"></script>
</body>
</html>